package com.example.homebudgetappfinalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class addrent extends AppCompatActivity {


    EditText Home,utilites,food,department,ent,mm;
    Button button;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_order);
        getSupportActionBar().hide();

        Home = (EditText) findViewById(R.id.homerent);
        utilites = (EditText) findViewById(R.id.Utilities);
        food = (EditText) findViewById(R.id.FOOD);
        department = (EditText) findViewById(R.id.Departmental);
        ent = (EditText) findViewById(R.id.Entertainment);
        mm = (EditText) findViewById(R.id.mm);
        button = (Button) findViewById(R.id.button2);
//

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();






        button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Map<String, Object> user = new HashMap<>();


                user.put("Rent ", Home.getText().toString());
                user.put("utilites ", utilites.getText().toString());
                user.put("food ", food.getText().toString());
                user.put("department ", department.getText().toString());
                user.put("Entertainment ", ent.getText().toString());
                user.put("date ", mm.getText().toString());


                // Toast.makeText(addrent.this, Home.getText().toString(), Toast.LENGTH_LONG).show();

                db.collection("Data")
                        .add(user)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                // Log.d('asd', "DocumentSnapshot added with ID: " + documentReference.getId());
//                        result.setText("Name:\t" + name + "\nPassword:\t" + password );
                                Context context = getApplicationContext();
                                CharSequence text = "Data Saved";
                                int duration = Toast.LENGTH_SHORT;

                                Toast toast = Toast.makeText(context, text, duration);
                                toast.show();
                                Intent i = new Intent(addrent.this, Dashboard.class);
                                startActivity(i);
                                // Initialize Firebase Auth


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                //Log.w('erro', "Error adding document", e);
//                        result.setText("Name:\t" + "not added" + "\nPassword:\t" + "not added password");
                            }
                        });


            }
        });



    }
}