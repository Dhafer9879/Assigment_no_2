package com.example.homebudgetappfinalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class viewOrder extends AppCompatActivity {
    private FirebaseAuth mAuth;
    EditText Home,utilites,food,department,ent,mm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_order);
        getSupportActionBar().hide();

        Home = (EditText) findViewById(R.id.homerent);
        utilites = (EditText) findViewById(R.id.Utilities);
        food = (EditText) findViewById(R.id.FOOD);
        department = (EditText) findViewById(R.id.Departmental);
        ent = (EditText) findViewById(R.id.Entertainment);
        mm = (EditText) findViewById(R.id.mm);


                Home.setFocusable(false);
                utilites.setFocusable(false);
                food.setFocusable(false);
                department.setFocusable(false);
                ent.setFocusable(false);
                mm.setFocusable(false);




        FirebaseFirestore db = FirebaseFirestore.getInstance();



        mAuth = FirebaseAuth.getInstance();

        Bundle bundle = getIntent().getExtras();
        String select_object_id = bundle.getString("select_object_id");


        DocumentReference docRef = db.collection("Data").document(select_object_id);
        docRef.get().addOnCompleteListener(viewOrder.this,new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());

                        Home.setText((document.getData().get("Rent ")).toString());
                        utilites.setText((document.getData().get("utilites ")).toString());
                        food.setText((document.getData().get("food ")).toString());
                        department.setText((document.getData().get("department ")).toString());
                        ent.setText((document.getData().get("Entertainment ")).toString());
                        mm.setText((document.getData().get("date ")).toString());




                        Log.d("TAG", "DocumentSnapshot data: " + document.getData().get("Entertainment"));
                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
            }
        });



//
//        orderdetailshowdata = (TextView)findViewById(R.id.orderdetailshowdata);
//        perrsonshow  = (TextView)findViewById(R.id.orderdetailshowperson);
//        tablenumbershow=(TextView)findViewById(R.id.tablenumbershow);
//        totalamount=(TextView)findViewById(R.id.totalAmount);
//        totalAmounttime= (TextView)findViewById(R.id.totalAmounttime);
//
//                //orderdetailshowperson
//        Bundle bundle = getIntent().getExtras();
//        String person = bundle.getString("person");
//        String tableno = bundle.getString("table");
//        String total = bundle.getString("total");
//        String time = bundle.getString("time");
////        orderdetailshowdata.setText(resultOrder.toString().substring(1,resultOrder.length()-2));
//
//
//     //   orderdetailshowdata.setText(person);
//        perrsonshow.setText(person);
//        tablenumbershow.setText(" #"+tableno);
//        totalamount.setText(total +"$");
//        totalAmounttime.setText(time +"Min");
    }
}