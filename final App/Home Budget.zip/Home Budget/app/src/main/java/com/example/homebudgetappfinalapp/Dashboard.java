package com.example.homebudgetappfinalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.json.JSONObject;

import java.util.ArrayList;

public class Dashboard extends AppCompatActivity {

    private FirebaseAuth mAuth;

    ArrayList<String>  maintitle= new ArrayList<>();
    String[] subtitle={
    };



    ArrayList<Integer> imgid = new ArrayList<>();


    Button buttonSubmit;
    // Array of strings...
//    String[] mobileArray = {};

    //ArrayList<String> dataarr = new ArrayList<String>();

    ArrayList<String> objectID = new ArrayList<String>();
//    ArrayList<String> totaLAmout = new ArrayList<String>();
//    ArrayList<String> personarr = new ArrayList<String>();
//    ArrayList<String> timearr = new ArrayList<String>();
//    ArrayList<String> itemOne = new ArrayList<String>();
//    ArrayList<String> itemTwo = new ArrayList<String>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);



        buttonSubmit = (Button) findViewById(R.id.button3);




        ListView listView = (ListView) findViewById(R.id.activity_listview);




        FirebaseFirestore db = FirebaseFirestore.getInstance();



        mAuth = FirebaseAuth.getInstance();
     //   JSONObject obj=new JSONObject();
     //   Intent i = new Intent(Dashboard.this, viewOrder.class);
        db.collection("Data")
                .get()
                .addOnCompleteListener(Dashboard.this,new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {

                        if (task.isSuccessful()) {
                            int indexValue=0;
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("result", document.getId() + " => " + document.getData());
                              //  Log.d("result", document.getId() + " => " + document.getData().get("Table No"));
                                            objectID.add(indexValue,document.getId().toString());

                                            imgid.add(indexValue,R.drawable.download_list);
                                              maintitle.add(indexValue,document.getId().toString());
                                            indexValue++;
                            }
                        } else {
                           Log.w("result", "Error getting documents.", task.getException());
                        }

                        MyListAdapter adapter=new MyListAdapter(Dashboard.this, maintitle, subtitle,imgid);

                        listView.setAdapter(adapter);


                        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                                //   TODO Auto-generated method stub

                                String value=objectID.get(position);
                                Toast.makeText(getApplicationContext(),value,Toast.LENGTH_SHORT).show();



                                Intent i = new Intent(Dashboard.this, viewOrder.class);


                               /// Bundle bundle = getIntent().getExtras();

                                i.putExtra("select_object_id", value);


                              startActivity(i);


                            }
                        });

                    }
                });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {



                Intent i = new Intent(Dashboard.this, addrent.class);

                startActivity(i);


            }
        });


    }
}